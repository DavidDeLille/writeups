/* $OpenBSD: version.h,v 1.71 2014/04/18 23:52:25 djm Exp $ */

#define SSH_VERSION	"OpenSSH_6.7"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
